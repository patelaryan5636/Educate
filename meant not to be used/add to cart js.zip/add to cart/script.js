let cartCount = 0;

function addToCart(courseName) {
    cartCount++;
    updateCart();
    alert(`Added ${courseName} to cart!`);
}

function updateCart() {
    const cartElement = document.getElementById('cart');
    cartElement.textContent = `Cart: ${cartCount} items`;
}

// Example course cards
const courses = [
    { name: 'Course 1', price: '$50' },
    { name: 'Course 2', price: '$30' },
    { name: 'Course 3', price: '$45' },
];

document.addEventListener('DOMContentLoaded', () => {
    const coursesSection = document.getElementById('courses');

    courses.forEach(course => {
        const courseCard = document.createElement('div');
        courseCard.classList.add('course');
        courseCard.innerHTML = `<h3>${course.name}</h3><p>${course.price}</p><button onclick="addToCart('${course.name}')">Add to Cart</button>`;
        coursesSection.appendChild(courseCard);
    });
});



// Add these functions at the end of script.js
function showCartPage() {
    // Redirect to the cart page or update the content dynamically
    // For simplicity, let's simulate a redirect by changing the content
    const coursesSection = document.getElementById('courses');
    coursesSection.innerHTML = '';
    const cartElement = document.getElementById('cart');
    cartElement.textContent = 'Cart: 0 items';
    
    // Display the cart page content
    const cartPageContent = document.createElement('div');
    cartPageContent.innerHTML = '<h2>Cart</h2><p>Your selected courses:</p><ul id="cartList"></ul>';
    coursesSection.appendChild(cartPageContent);

    // Update the cart list dynamically
    const cartList = document.getElementById('cartList');
    for (const course of selectedCourses) {
        const cartItem = document.createElement('li');
        cartItem.textContent = course;
        cartList.appendChild(cartItem);
    }
}

// Array to store selected courses
const selectedCourses = [];

function addToCart(courseName) {
    selectedCourses.push(courseName);
    updateCart();
    alert(`Added ${courseName} to cart!`);
}

// Rest of the existing code remains the same
